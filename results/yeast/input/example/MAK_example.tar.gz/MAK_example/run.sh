java -Xmx2G DataMining.RunMiner -param MAK_parameters.txt -debug 0
